from libraries import *

file = 'fitness_data_wt.rds'
result = pyreadr.read_r(file)
df1 = result[None]
variants = df1.SV
fitnesses = df1.m

fitness_data = {}

for i in range(len(variants)):
    fitness_data[variants[i]] = fitnesses[i]

print(len(fitness_data),'data compiled')

nucleotides = ['A','T','G','C']

threshold = -0.507774

no_epi_margin = 0.05

codon_table = {'Lys': ['AAA', 'AAG'],
               'Asn': ['AAT', 'AAC'],
               'Ile': ['ATA', 'ATT', 'ATC'],
               'Met': ['ATG'],
               'Arg': ['AGA', 'AGG', 'CGA', 'CGT', 'CGG', 'CGC'],
               'Ser': ['AGT', 'AGC', 'TCA', 'TCT', 'TCG', 'TCC'],
               'Thr': ['ACA', 'ACT', 'ACG', 'ACC'],
               'stop': ['TAA', 'TAG', 'TGA'],
               'Tyr': ['TAT', 'TAC'],
               'Leu': ['TTA', 'TTG', 'CTA', 'CTT', 'CTG', 'CTC'],
               'Phe': ['TTT', 'TTC'],
               'Cys': ['TGT', 'TGC'],
               'Trp': ['TGG'],
               'Glu': ['GAA', 'GAG'],
               'Asp': ['GAT', 'GAC'],
               'Val': ['GTA', 'GTT', 'GTG', 'GTC'],
               'Gly': ['GGA', 'GGT', 'GGG', 'GGC'],
               'Ala': ['GCA', 'GCT', 'GCG', 'GCC'],
               'Gln': ['CAA', 'CAG'],
               'His': ['CAT', 'CAC'],
               'Pro': ['CCT', 'CCG', 'CCC', 'CCA']}
