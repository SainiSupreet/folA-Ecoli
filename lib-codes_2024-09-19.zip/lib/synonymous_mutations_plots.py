from bio_functions import *

plt.rcParams["figure.figsize"] = (60,50)
plt.rcParams['axes.linewidth'] = 20
plt.rcParams['lines.linewidth'] = 10
plt.rcParams['xtick.major.size']=60
plt.rcParams['xtick.major.width']=15
plt.rcParams['ytick.major.size']=60
plt.rcParams['ytick.major.width']=15
plt.rcParams['axes.labelpad'] = 40

plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['figure.constrained_layout.h_pad']=0.5
plt.rcParams['figure.constrained_layout.w_pad']=0.5
plt.rcParams['savefig.pad_inches'] = 0.5

# Functional
data = pd.read_csv('../Epistasis/Summary table of epistasis change by synonymous mutation - Functional.csv')

plt.ylim(0,1)
plt.xlim(0.5,9.5)

bp = plt.bar(data['X locus'].values,
             data['Change'].values/(data['Change'].values + data['No change'].values),
             label = 'Pivot points',color = 'teal',
             width = 0.6,edgecolor = 'black',
             linewidth = 12)

plt.bar_label(bp,[round(i,2) for i in data['Change'].values/(data['Change'].values + data['No change'].values)],
              fontsize = 115)
plt.xticks(fontsize=165)
plt.yticks(fontsize=180)
plt.tick_params(axis = 'both',direction = 'inout',pad = 20)

plt.ylabel('Fraction of backgrounds\nwhere epistasis changes',fontsize = 200)
plt.xlabel('Synonymous mutation locus',fontsize = 200)

plt.locator_params(axis='y', nbins=6)

plt.savefig('../Plots/Epistasis change locus/Synonymous mutations - functional background')
plt.close()

# Non functional
data = pd.read_csv('../Epistasis/Summary table of epistasis change by synonymous mutation - Non Functional.csv')

plt.ylim(0,1)
plt.xlim(0.5,9.5)

bp = plt.bar(data['X locus'].values,
             data['Change'].values/(data['Change'].values + data['No change'].values),
             label = 'Pivot points',color = 'teal',
             width = 0.6,edgecolor = 'black',
             linewidth = 12)

plt.bar_label(bp,[round(i,2) for i in data['Change'].values/(data['Change'].values + data['No change'].values)],
              fontsize = 115)
plt.xticks(fontsize=165)
plt.yticks(fontsize=180)
plt.tick_params(axis = 'both',direction = 'inout',pad = 20)

plt.ylabel('Fraction of backgrounds\nwhere epistasis changes',fontsize = 200)
plt.xlabel('Synonymous mutation locus',fontsize = 200)

plt.locator_params(axis='y', nbins=6)

plt.savefig('../Plots/Epistasis change locus/Synonymous mutations - non functional background')
plt.close()

# Non functional
data = pd.read_csv('../Epistasis/Summary table of epistasis change by synonymous mutation - All.csv')

plt.ylim(0,1)
plt.xlim(0.5,9.5)

bp = plt.bar(data['X locus'].values,
             data['Change'].values/(data['Change'].values + data['No change'].values),
             label = 'Pivot points',color = 'teal',
             width = 0.6,edgecolor = 'black',
             linewidth = 12)

plt.bar_label(bp,[round(i,2) for i in data['Change'].values/(data['Change'].values + data['No change'].values)],
              fontsize = 115)
plt.xticks(fontsize=165)
plt.yticks(fontsize=180)
plt.tick_params(axis = 'both',direction = 'inout',pad = 20)

plt.ylabel('Fraction of backgrounds\nwhere epistasis changes',fontsize = 200)
plt.xlabel('Synonymous mutation locus',fontsize = 200)

plt.locator_params(axis='y', nbins=6)

plt.savefig('../Plots/Epistasis change locus/Synonymous mutations - all backgrounds')
plt.close()
