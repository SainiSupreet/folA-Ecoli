from bio_functions import *

plt.rcParams["figure.figsize"] = (50,50)
plt.rcParams['axes.linewidth'] = 20
plt.rcParams['lines.linewidth'] = 15
plt.rcParams['xtick.major.size']=50
plt.rcParams['xtick.major.width']=10
plt.rcParams['ytick.major.size']=50
plt.rcParams['ytick.major.width']=10

plt.rcParams['axes.labelpad'] = 60

plt.rcParams['boxplot.meanprops.linewidth'] = 10
plt.rcParams['boxplot.capprops.linewidth']= 10
plt.rcParams['boxplot.meanprops.markersize'] = 10
plt.rcParams['boxplot.whiskerprops.linewidth'] = 7
plt.rcParams['boxplot.flierprops.linewidth'] = 7
plt.rcParams['boxplot.boxprops.linewidth']=7

plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['figure.constrained_layout.h_pad']=0.5
plt.rcParams['figure.constrained_layout.w_pad']=0.5
plt.rcParams['savefig.pad_inches'] = 0.5

plt.rcParams['grid.linewidth']=3

epistasis = ['Positive','Negative','Reciprocal Sign','Single Sign','Other Sign','No Epistasis']

# Functional epistasis (bg)
data = pd.read_csv('../Epistasis/Detailed data - epistasis change/Functional Epistasis - fractions.csv')

epi_lists = []
for epi in epistasis:
    epi_data = data[epi][data[epi].notna() == True].values
    epi_lists.append(epi_data)

vp = sns.violinplot(epi_lists,linewidth = 7,density_norm = 'count',color = 'lightcoral',
                    inner_kws=dict(box_width=40, whis_width=10,color = 'black'))

##plt.legend([bp['means'][0],bp['medians'][0]],
##           ['Mean','Median'],frameon=False,fontsize=150)

plt.xticks(range(6),['PE','NE','RSE','SSE','OSE','No'],fontsize = 150)
plt.yticks(fontsize = 150)
plt.ylim(0,1)

plt.locator_params(axis='y',nbins=6)

plt.grid()

plt.xlabel('Nature of epistasis',fontsize = 175)
plt.ylabel('Fraction of genotypes',fontsize = 175)
plt.savefig('../Plots/Epistasis change locus/Functional epistasis')

plt.close()

# Non functional epistasis (bg)

data = pd.read_csv('../Epistasis/Detailed data - epistasis change/Non Functional Epistasis - fractions.csv')

epi_lists = []
for epi in epistasis:
    epi_data = data[epi][data[epi].notna() == True].values
    epi_lists.append(epi_data)

vp = sns.violinplot(epi_lists,linewidth = 7,density_norm = 'count',color = 'lightcoral',
                    inner_kws=dict(box_width=40, whis_width=10,color = 'black'))

##plt.legend([bp['means'][0],bp['medians'][0]],
##           ['Mean','Median'],frameon=False,fontsize=150)

plt.xticks(range(6),['PE','NE','RSE','SSE','OSE','No'],fontsize = 150)
plt.yticks(fontsize = 150)
plt.ylim(0,1)

plt.locator_params(axis='y',nbins=6)

plt.grid()

plt.xlabel('Nature of epistasis',fontsize = 175)
plt.ylabel('Fraction of genotypes',fontsize = 175)
plt.savefig('../Plots/Epistasis change locus/Non Functional epistasis')

plt.close()

# Compiled data
data = pd.read_csv('../Epistasis/Detailed data - epistasis change/Table - fractions.csv')

locus_list = []
for i in range(1,10):
    locus_data = data[f'X locus {i}'][data[f'X locus {i}'].notna() == True].values
    locus_list.append(locus_data)

##bp = plt.boxplot(locus_list,showmeans = True,meanline = True,
##                 showfliers = False,
##                 medianprops=dict(linestyle='-', linewidth=15,
##                                  color='black'),
##                 meanprops=dict(linestyle='--', linewidth=15,
##                                color='red'))

vp = sns.violinplot(locus_list,linewidth = 7,density_norm = 'count',color = 'lightcoral',
                    inner_kws=dict(box_width=40, whis_width=10,color = 'black'))

##plt.legend([bp['means'][0],bp['medians'][0]],
##           ['Mean','Median'],frameon=False,fontsize=150)

plt.xticks(range(9),range(1,10),fontsize = 150)
plt.yticks(fontsize = 150)
plt.ylim(0,1)

plt.locator_params(axis='y',nbins=6)

plt.grid()

plt.xlabel('Mutation X locus',fontsize = 175)
plt.ylabel('Probability of epistasis change',fontsize = 175)
plt.savefig('../Plots/Epistasis change locus/Compiled probability')

plt.close()

# Functional data
data = pd.read_csv('../Epistasis/Detailed data - epistasis change/Functional table - fractions.csv')

locus_list = []
for i in range(1,10):
    locus_data = data[f'X locus {i}'][data[f'X locus {i}'].notna() == True].values
    locus_list.append(locus_data)

##bp = plt.boxplot(locus_list,showmeans = True,meanline = True,
##                 showfliers = False,
##                 medianprops=dict(linestyle='-', linewidth=15,
##                                  color='black'),
##                 meanprops=dict(linestyle='--', linewidth=15,
##                                color='red'))

vp = sns.violinplot(locus_list,linewidth = 7,density_norm = 'count',color = 'lightcoral',
                    inner_kws=dict(box_width=40, whis_width=10,color = 'black'))

##plt.legend([bp['means'][0],bp['medians'][0]],
##           ['Mean','Median'],frameon=False,fontsize=150)

plt.xticks(range(9),range(1,10),fontsize = 150)
plt.yticks(fontsize = 150)
plt.ylim(0,1)

plt.locator_params(axis='y',nbins=6)

plt.grid()

plt.xlabel('Mutation X locus',fontsize = 175)
plt.ylabel('Probability of epistasis change',fontsize = 175)
plt.savefig('../Plots/Epistasis change locus/Functional probability')

plt.close()

# Non Functional data
data = pd.read_csv('../Epistasis/Detailed data - epistasis change/Non Functional table - fractions.csv')

locus_list = []
for i in range(1,10):
    locus_data = data[f'X locus {i}'][data[f'X locus {i}'].notna() == True].values
    locus_list.append(locus_data)

##bp = plt.boxplot(locus_list,showmeans = True,meanline = True,
##                 showfliers = False,
##                 medianprops=dict(linestyle='-', linewidth=15,
##                                  color='black'),
##                 meanprops=dict(linestyle='--', linewidth=15,
##                                color='red'))

vp = sns.violinplot(locus_list,linewidth = 7,density_norm = 'count',color = 'lightcoral',
                    inner_kws=dict(box_width=40, whis_width=10,color = 'black'))

##plt.legend([bp['means'][0],bp['medians'][0]],
##           ['Mean','Median'],frameon=False,fontsize=150)

plt.xticks(range(9),range(1,10),fontsize = 150)
plt.yticks(fontsize = 150)
plt.ylim(0,1)

plt.locator_params(axis='y',nbins=6)

plt.grid()

plt.xlabel('Mutation X locus',fontsize = 175)
plt.ylabel('Probability of epistasis change',fontsize = 175)
plt.savefig('../Plots/Epistasis change locus/Non Functional probability')

plt.close()

# Functional change

epistasis = ['Positive','Negative','Reciprocal Sign','Single Sign','Other Sign','No Epistasis']

epistasis_change_pairs = []
for i in epistasis:
    for j in epistasis:
        epistasis_change_pairs.append((i,j))

for epi_pair in epistasis_change_pairs:
    data = pd.read_csv\
           (f'../Epistasis/Detailed data - epistasis change/Epistasis change fraction/\
Functional {epi_pair[0]} -> {epi_pair[1]} - fractions.csv')

    locus_list = []
    for i in range(1,10):
        locus_data = data[f'X locus {i}'][data[f'X locus {i}'].notna() == True].values
        locus_list.append(locus_data)

    ##bp = plt.boxplot(locus_list,showmeans = True,meanline = True,
    ##                 showfliers = False,
    ##                 medianprops=dict(linestyle='-', linewidth=15,
    ##                                  color='black'),
    ##                 meanprops=dict(linestyle='--', linewidth=15,
    ##                                color='red'))

    vp = sns.violinplot(locus_list,linewidth = 7,density_norm = 'count',color = 'lightcoral',
                        inner_kws=dict(box_width=40, whis_width=10,color = 'black'))

    ##plt.legend([bp['means'][0],bp['medians'][0]],
    ##           ['Mean','Median'],frameon=False,fontsize=150)

    plt.xticks(range(9),range(1,10),fontsize = 150)
    plt.yticks(fontsize = 150)
    plt.ylim(0,1)

    plt.locator_params(axis='y',nbins=6)

    plt.grid()

    plt.xlabel('Mutation X locus',fontsize = 175)
    plt.ylabel('Probability of epistasis change',fontsize = 175)
    plt.savefig(f'../Plots/Epistasis change locus/\
Functional {epi_pair[0]} -> {epi_pair[1]} probability')

    plt.close()

# Non Functional change

epistasis = ['Positive','Negative','Reciprocal Sign','Single Sign','Other Sign','No Epistasis']

epistasis_change_pairs = []
for i in epistasis:
    for j in epistasis:
        epistasis_change_pairs.append((i,j))

for epi_pair in epistasis_change_pairs:
    data = pd.read_csv\
           (f'../Epistasis/Detailed data - epistasis change/Epistasis change fraction/\
Non Functional {epi_pair[0]} -> {epi_pair[1]} - fractions.csv')

    locus_list = []
    for i in range(1,10):
        locus_data = data[f'X locus {i}'][data[f'X locus {i}'].notna() == True].values
        locus_list.append(locus_data)

    ##bp = plt.boxplot(locus_list,showmeans = True,meanline = True,
    ##                 showfliers = False,
    ##                 medianprops=dict(linestyle='-', linewidth=15,
    ##                                  color='black'),
    ##                 meanprops=dict(linestyle='--', linewidth=15,
    ##                                color='red'))

    vp = sns.violinplot(locus_list,linewidth = 7,density_norm = 'count',color = 'lightcoral',
                        inner_kws=dict(box_width=40, whis_width=10,color = 'black'))

    ##plt.legend([bp['means'][0],bp['medians'][0]],
    ##           ['Mean','Median'],frameon=False,fontsize=150)

    plt.xticks(range(9),range(1,10),fontsize = 150)
    plt.yticks(fontsize = 150)
    plt.ylim(0,1)

    plt.locator_params(axis='y',nbins=6)

    plt.grid()

    plt.xlabel('Mutation X locus',fontsize = 175)
    plt.ylabel('Probability of epistasis change',fontsize = 175)
    plt.savefig(f'../Plots/Epistasis change locus/\
Non Functional {epi_pair[0]} -> {epi_pair[1]} probability')

    plt.close()
